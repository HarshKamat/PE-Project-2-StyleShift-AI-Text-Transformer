import type { Express } from "express";
import { createServer, type Server } from "http";
import { generateTransformedText } from "./openai";
import { transformTextSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Transform text endpoint
  app.post("/api/transform", async (req, res) => {
    try {
      // Validate request body
      const { text, style } = transformTextSchema.parse(req.body);
      
      // Get transformed text from OpenAI
      const result = await generateTransformedText(text, style);
      
      // Return the response
      return res.json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid request body", 
          errors: error.errors 
        });
      }
      
      // Log the error
      console.error("Error in /api/transform:", error);
      
      return res.status(500).json({ 
        message: "Failed to transform text. Please try again." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
