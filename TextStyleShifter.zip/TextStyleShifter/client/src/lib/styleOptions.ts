export const styleOptions = [
  { value: "poem", label: "Poem" },
  { value: "explanation", label: "Explanation" },
  { value: "summary", label: "Summary" },
  { value: "code-comment", label: "Code Comment" },
  { value: "tweet", label: "Tweet" },
  { value: "academic", label: "Academic Paper" },
  { value: "story", label: "Short Story" }
];
