export default function InfoPanel() {
  return (
    <div className="mt-8 bg-neutral-50 border border-neutral-200 rounded-lg p-4">
      <h3 className="text-md font-medium text-neutral-800 mb-2">About this tool</h3>
      <p className="text-sm text-neutral-600">
        This multi-style text generator uses OpenAI's GPT API to transform your input into various writing styles. 
        The tool demonstrates how prompt engineering can guide AI to produce different creative outputs from the same source material.
      </p>
    </div>
  );
}
