import { MessageSquare } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <MessageSquare className="h-8 w-8 text-primary" />
            <h1 className="ml-2 text-xl font-semibold text-neutral-900">Prompt Playground</h1>
          </div>
          <div>
            <span className="px-3 py-1 bg-primary-50 text-primary-700 text-sm font-medium rounded-full">
              Multi-Style Text Generator
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
