import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Info } from "lucide-react";
import { styleOptions } from "@/lib/styleOptions";

interface InputPanelProps {
  inputText: string;
  setInputText: (text: string) => void;
  selectedStyle: string;
  setSelectedStyle: (style: string) => void;
  handleSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
}

export default function InputPanel({
  inputText,
  setInputText,
  selectedStyle,
  setSelectedStyle,
  handleSubmit,
  isLoading
}: InputPanelProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
      <h2 className="text-lg font-semibold text-neutral-900 mb-4">Transform Your Text</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="input-text" className="block text-sm font-medium text-neutral-700 mb-1">
            Enter your text
          </label>
          <Textarea
            id="input-text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type or paste your text here..."
            rows={4}
            className="resize-none focus:ring-primary focus:border-primary"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="col-span-1 md:col-span-2">
            <label htmlFor="style-select" className="block text-sm font-medium text-neutral-700 mb-1">
              Select transformation style
            </label>
            <Select
              value={selectedStyle}
              onValueChange={setSelectedStyle}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a style" />
              </SelectTrigger>
              <SelectContent>
                {styleOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-end">
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary-700 text-white font-medium"
              disabled={isLoading || !inputText.trim()}
            >
              {isLoading ? (
                <>
                  <span className="mr-2">Generating</span>
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </>
              ) : "Generate"}
            </Button>
          </div>
        </div>
      </form>
      
      <div className="bg-neutral-50 border border-neutral-200 rounded-md p-3 text-sm text-neutral-600 mt-2">
        <p className="font-medium mb-1 text-neutral-700 flex items-center">
          <Info className="h-5 w-5 mr-1 text-primary" />
          How it works:
        </p>
        <ol className="list-decimal list-inside space-y-1">
          <li>Enter your text in the input field</li>
          <li>Select a transformation style</li>
          <li>Click "Generate" to transform your text using AI</li>
        </ol>
      </div>
    </div>
  );
}
