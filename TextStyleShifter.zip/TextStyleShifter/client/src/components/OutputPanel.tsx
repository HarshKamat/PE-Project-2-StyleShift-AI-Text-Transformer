import { Card } from "@/components/ui/card";
import { Copy, AlertCircle, Inbox, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { styleOptions } from "@/lib/styleOptions";

interface OutputPanelProps {
  response: string | null;
  responseStyle: string;
  isLoading: boolean;
  hasError: boolean;
  handleCopy: () => void;
  tokenCount: number | null;
}

export default function OutputPanel({
  response,
  responseStyle,
  isLoading,
  hasError,
  handleCopy,
  tokenCount
}: OutputPanelProps) {
  const { toast } = useToast();
  
  const selectedStyleOption = styleOptions.find(option => option.value === responseStyle);
  const styleName = selectedStyleOption?.label || "Custom style";
  
  const onCopy = () => {
    if (response) {
      handleCopy();
      toast({
        title: "Copied to clipboard",
        description: "The generated text has been copied to your clipboard.",
        duration: 2000,
      });
    }
  };
  
  return (
    <Card className="p-6 bg-white shadow-sm mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-neutral-900">Generated Output</h2>
        
        <button
          onClick={onCopy}
          className="text-neutral-500 hover:text-neutral-700 flex items-center text-sm font-medium px-3 py-1 rounded-md hover:bg-neutral-100 transition duration-150 ease-in-out"
          disabled={!response || isLoading}
        >
          <Copy className="h-4 w-4 mr-1" />
          Copy
        </button>
      </div>
      
      <div className="min-h-[200px] rounded-md bg-neutral-50 border border-neutral-200 p-4">
        {isLoading && (
          <div className="flex flex-col items-center justify-center h-[200px] text-neutral-400">
            <Loader2 className="animate-spin h-8 w-8 mb-2" />
            <p>Generating your response...</p>
          </div>
        )}
        
        {!isLoading && !response && !hasError && (
          <div className="flex flex-col items-center justify-center h-[200px] text-neutral-400">
            <Inbox className="h-12 w-12 mb-2" />
            <p>Your transformed text will appear here</p>
          </div>
        )}
        
        {!isLoading && hasError && (
          <div className="flex flex-col items-center justify-center h-[200px] text-red-500">
            <AlertCircle className="h-12 w-12 mb-2" />
            <p>Something went wrong. Please try again.</p>
          </div>
        )}
        
        {!isLoading && response && !hasError && (
          <div className={`prose max-w-none ${responseStyle === 'poem' ? 'italic text-center space-y-4 leading-relaxed' : 'space-y-3 leading-relaxed'}`}>
            {response.split('\n').map((line, index) => (
              <p key={index}>{line}</p>
            ))}
          </div>
        )}
      </div>
      
      <div className="mt-4 flex items-center text-sm text-neutral-500">
        <span className="inline-flex items-center">
          <span className="w-3 h-3 rounded-full bg-primary mr-2"></span>
          <span>{styleName}</span>
        </span>
        {tokenCount !== null && (
          <>
            <span className="mx-3">•</span>
            <span>Tokens: ~{tokenCount}</span>
          </>
        )}
      </div>
    </Card>
  );
}
