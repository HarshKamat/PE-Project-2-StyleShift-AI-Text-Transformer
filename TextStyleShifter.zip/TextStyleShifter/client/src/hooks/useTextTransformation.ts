import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { TextTransformResult } from "@shared/schema";

interface TransformParams {
  text: string;
  style: string;
}

export function useTextTransformation() {
  const [response, setResponse] = useState<string | null>(null);
  const [tokenCount, setTokenCount] = useState<number | null>(null);
  
  const { mutate, isPending, error } = useMutation({
    mutationFn: async (params: TransformParams) => {
      const res = await apiRequest("POST", "/api/transform", params);
      return res.json() as Promise<TextTransformResult>;
    },
    onSuccess: (data) => {
      setResponse(data.text);
      setTokenCount(data.tokens);
    },
    onError: () => {
      setResponse(null);
      setTokenCount(null);
    }
  });
  
  return {
    transform: mutate,
    response,
    isLoading: isPending,
    error,
    tokenCount
  };
}
