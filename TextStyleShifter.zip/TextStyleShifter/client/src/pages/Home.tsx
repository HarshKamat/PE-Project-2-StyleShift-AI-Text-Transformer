import Header from "@/components/Header";
import Footer from "@/components/Footer";
import InputPanel from "@/components/InputPanel";
import OutputPanel from "@/components/OutputPanel";
import InfoPanel from "@/components/InfoPanel";
import { useState } from "react";
import { useTextTransformation } from "@/hooks/useTextTransformation";

export default function Home() {
  const [inputText, setInputText] = useState("");
  const [selectedStyle, setSelectedStyle] = useState("poem");
  
  const {
    transform,
    response,
    isLoading,
    error,
    tokenCount
  } = useTextTransformation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputText.trim()) {
      return;
    }
    
    await transform({
      text: inputText,
      style: selectedStyle
    });
  };

  const handleCopy = () => {
    if (response) {
      navigator.clipboard.writeText(response);
    }
  };

  return (
    <div className="bg-neutral-50 min-h-screen flex flex-col">
      <Header />
      
      <main className="max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <InputPanel 
          inputText={inputText}
          setInputText={setInputText}
          selectedStyle={selectedStyle}
          setSelectedStyle={setSelectedStyle}
          handleSubmit={handleSubmit}
          isLoading={isLoading}
        />
        
        <OutputPanel 
          response={response}
          responseStyle={selectedStyle}
          isLoading={isLoading}
          hasError={!!error}
          handleCopy={handleCopy}
          tokenCount={tokenCount}
        />
        
        <InfoPanel />
      </main>
      
      <Footer />
    </div>
  );
}
